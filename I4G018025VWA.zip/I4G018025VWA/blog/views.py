from django.shortcuts import render

# Create your views here.
from django.views.generic.list import ListView
from .models import Post
 
class PostListView(ListView):
 
    # specify the model for list view
    model = Post

class PostCreateView(CreateView):
    model = Post

    fields = “__all__”

class PostDeleteView(UpdateView):
    model = Post

    fields = “__all__”

    success_url  = reverse_lazy(“blog:all”)

    